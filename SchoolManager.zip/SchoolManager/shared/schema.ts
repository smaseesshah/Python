import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, boolean, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Students table
export const students = pgTable("students", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: text("student_id").notNull().unique(),
  name: text("name").notNull(),
  fatherName: text("father_name").notNull(),
  motherName: text("mother_name").notNull(),
  dateOfBirth: text("date_of_birth").notNull(),
  address: text("address").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  class: text("class").notNull(),
  rollNumber: text("roll_number").notNull(),
  admissionDate: text("admission_date").notNull(),
  isActive: boolean("is_active").default(true),
});

// Classes and subjects
export const classes = pgTable("classes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  subjects: json("subjects").$type<string[]>().notNull().default([]),
});

// Fee structures
export const feeStructures = pgTable("fee_structures", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  class: text("class").notNull(),
  admissionFee: decimal("admission_fee", { precision: 10, scale: 2 }).notNull(),
  monthlyFee: decimal("monthly_fee", { precision: 10, scale: 2 }).notNull(),
  examFee: decimal("exam_fee", { precision: 10, scale: 2 }).notNull(),
  otherFees: json("other_fees").$type<{ name: string; amount: number }[]>().default([]),
});

// Fee payments
export const feePayments = pgTable("fee_payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  receiptNumber: text("receipt_number").notNull().unique(),
  studentId: text("student_id").notNull(),
  feeType: text("fee_type").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  paymentDate: text("payment_date").notNull(),
  paymentMode: text("payment_mode").notNull(),
  month: text("month"),
  year: text("year"),
  remarks: text("remarks"),
});

// Exams
export const exams = pgTable("exams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'assessment', 'mid', 'final'
  class: text("class").notNull(),
  year: text("year").notNull(),
  isCompleted: boolean("is_completed").default(false),
});

// Exam results
export const examResults = pgTable("exam_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  examId: text("exam_id").notNull(),
  studentId: text("student_id").notNull(),
  subject: text("subject").notNull(),
  marks: integer("marks").notNull(),
  totalMarks: integer("total_marks").notNull().default(100),
  grade: text("grade"),
  isPassed: boolean("is_passed").notNull(),
});

// Insert schemas
export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
});

export const insertClassSchema = createInsertSchema(classes).omit({
  id: true,
});

export const insertFeeStructureSchema = createInsertSchema(feeStructures).omit({
  id: true,
});

export const insertFeePaymentSchema = createInsertSchema(feePayments).omit({
  id: true,
});

export const insertExamSchema = createInsertSchema(exams).omit({
  id: true,
});

export const insertExamResultSchema = createInsertSchema(examResults).omit({
  id: true,
});

// Types
export type Student = typeof students.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Class = typeof classes.$inferSelect;
export type InsertClass = z.infer<typeof insertClassSchema>;
export type FeeStructure = typeof feeStructures.$inferSelect;
export type InsertFeeStructure = z.infer<typeof insertFeeStructureSchema>;
export type FeePayment = typeof feePayments.$inferSelect;
export type InsertFeePayment = z.infer<typeof insertFeePaymentSchema>;
export type Exam = typeof exams.$inferSelect;
export type InsertExam = z.infer<typeof insertExamSchema>;
export type ExamResult = typeof examResults.$inferSelect;
export type InsertExamResult = z.infer<typeof insertExamResultSchema>;
