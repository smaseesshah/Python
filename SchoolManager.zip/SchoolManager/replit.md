# Overview

This is a comprehensive School Management System built with a modern full-stack architecture. The application provides functionality for managing students, classes, subjects, exams, fee payments, and generating various reports. It's designed for educational institutions to streamline their administrative processes with features like student enrollment, fee tracking, exam result management, and automated report generation.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript for type safety and better development experience
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state management and caching
- **UI Framework**: Shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling
- **Form Handling**: React Hook Form with Zod validation for robust form management
- **Build Tool**: Vite for fast development and optimized production builds

## Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API endpoints
- **Language**: TypeScript for type safety across the entire stack
- **Database Layer**: Drizzle ORM with PostgreSQL for type-safe database operations
- **Schema Validation**: Zod schemas shared between client and server for consistent data validation
- **File Structure**: Monorepo structure with shared schemas and separate client/server directories

## Database Design
- **Students Table**: Core student information including personal details, class assignment, and enrollment data
- **Classes Table**: Class definitions with associated subjects stored as JSON arrays
- **Fee Structures Table**: Configurable fee types per class with support for multiple fee categories
- **Fee Payments Table**: Payment tracking with receipt generation and audit trail
- **Exams Table**: Exam definitions with class and type categorization
- **Exam Results Table**: Individual student results linked to specific exams and subjects

## Key Design Patterns
- **Shared Schema Approach**: Common TypeScript types and Zod validators between frontend and backend
- **Component-Based UI**: Reusable UI components with consistent design system
- **Query-Based Data Fetching**: React Query for efficient data synchronization and caching
- **Form Validation**: Consistent validation using shared Zod schemas
- **Print-Friendly Design**: Dedicated print templates for receipts and report cards

## Authentication & Security
- Session-based authentication using connect-pg-simple for PostgreSQL session storage
- Input validation on both client and server sides using shared Zod schemas
- Type-safe API endpoints with proper error handling

# External Dependencies

## Database
- **Neon Database**: Serverless PostgreSQL database with connection pooling
- **Drizzle ORM**: Type-safe database operations and migrations
- **connect-pg-simple**: PostgreSQL session store for Express sessions

## UI & Styling
- **Tailwind CSS**: Utility-first CSS framework for rapid UI development
- **Radix UI**: Headless UI components for accessibility and functionality
- **Shadcn/ui**: Pre-built component library built on Radix UI
- **Lucide React**: Icon library for consistent iconography

## Development Tools
- **TypeScript**: Static type checking across the entire application
- **Vite**: Modern build tool with hot module replacement
- **ESBuild**: Fast JavaScript bundler for production builds
- **React Hook Form**: Performant form library with minimal re-renders
- **TanStack React Query**: Data fetching and caching solution

## Third-Party Integrations
- **Date-fns**: Date manipulation and formatting utilities
- **Wouter**: Lightweight client-side routing
- **Class Variance Authority**: Utility for creating variant-based component APIs
- **CLSX & Tailwind Merge**: Conditional class name utilities