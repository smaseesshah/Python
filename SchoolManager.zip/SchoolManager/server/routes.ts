import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertStudentSchema, insertFeePaymentSchema, insertExamSchema, insertExamResultSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Student routes
  app.get("/api/students", async (req, res) => {
    try {
      const students = await storage.getStudents();
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch students" });
    }
  });

  app.get("/api/students/search", async (req, res) => {
    try {
      const { q } = req.query;
      if (!q || typeof q !== 'string') {
        return res.status(400).json({ message: "Search query is required" });
      }
      const students = await storage.searchStudents(q);
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to search students" });
    }
  });

  app.get("/api/students/class/:className", async (req, res) => {
    try {
      const { className } = req.params;
      const students = await storage.getStudentsByClass(className);
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch students by class" });
    }
  });

  app.get("/api/students/pending-fees", async (req, res) => {
    try {
      const students = await storage.getStudentsWithPendingFees();
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch students with pending fees" });
    }
  });

  app.get("/api/students/failed-results", async (req, res) => {
    try {
      const students = await storage.getStudentsWithFailedResults();
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch students with failed results" });
    }
  });

  app.get("/api/students/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const student = await storage.getStudent(id);
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      res.json(student);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch student" });
    }
  });

  app.post("/api/students", async (req, res) => {
    try {
      const validation = insertStudentSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid student data", errors: validation.error.errors });
      }
      
      // Generate student ID
      const currentYear = new Date().getFullYear();
      const existingStudents = await storage.getStudents();
      const nextId = (existingStudents.length + 1).toString().padStart(3, '0');
      const studentId = `UMS${currentYear}${nextId}`;
      
      const studentData = { ...validation.data, studentId };
      const student = await storage.createStudent(studentData);
      res.status(201).json(student);
    } catch (error) {
      res.status(500).json({ message: "Failed to create student" });
    }
  });

  app.put("/api/students/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const validation = insertStudentSchema.partial().safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid student data", errors: validation.error.errors });
      }
      
      const student = await storage.updateStudent(id, validation.data);
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      res.json(student);
    } catch (error) {
      res.status(500).json({ message: "Failed to update student" });
    }
  });

  app.delete("/api/students/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteStudent(id);
      if (!success) {
        return res.status(404).json({ message: "Student not found" });
      }
      res.json({ message: "Student deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete student" });
    }
  });

  // Classes routes
  app.get("/api/classes", async (req, res) => {
    try {
      const classes = await storage.getClasses();
      res.json(classes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch classes" });
    }
  });

  // Fee structure routes
  app.get("/api/fee-structures", async (req, res) => {
    try {
      const feeStructures = await storage.getFeeStructures();
      res.json(feeStructures);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch fee structures" });
    }
  });

  app.get("/api/fee-structures/:className", async (req, res) => {
    try {
      const { className } = req.params;
      const feeStructure = await storage.getFeeStructureByClass(className);
      if (!feeStructure) {
        return res.status(404).json({ message: "Fee structure not found" });
      }
      res.json(feeStructure);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch fee structure" });
    }
  });

  // Fee payments routes
  app.get("/api/fee-payments", async (req, res) => {
    try {
      const payments = await storage.getFeePayments();
      res.json(payments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch fee payments" });
    }
  });

  app.get("/api/fee-payments/student/:studentId", async (req, res) => {
    try {
      const { studentId } = req.params;
      const payments = await storage.getFeePaymentsByStudent(studentId);
      res.json(payments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch student fee payments" });
    }
  });

  app.post("/api/fee-payments", async (req, res) => {
    try {
      const receiptNumber = await storage.getNextReceiptNumber();
      
      // Additional validation for required fields
      const { studentId, feeType, amount, paymentMode, paymentDate } = req.body;
      if (!studentId || !feeType || !amount || !paymentMode || !paymentDate) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      if (typeof studentId !== 'string' || studentId.trim() === '' ||
          typeof feeType !== 'string' || feeType.trim() === '' ||
          typeof amount !== 'string' || amount.trim() === '' ||
          typeof paymentMode !== 'string' || paymentMode.trim() === '' ||
          typeof paymentDate !== 'string' || paymentDate.trim() === '') {
        return res.status(400).json({ message: "Required fields cannot be empty" });
      }
      
      const validation = insertFeePaymentSchema.safeParse({ ...req.body, receiptNumber });
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid payment data", errors: validation.error.errors });
      }
      
      const payment = await storage.createFeePayment(validation.data);
      res.status(201).json(payment);
    } catch (error) {
      res.status(500).json({ message: "Failed to record payment" });
    }
  });

  // Exam routes
  app.get("/api/exams", async (req, res) => {
    try {
      const exams = await storage.getExams();
      res.json(exams);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch exams" });
    }
  });

  app.get("/api/exams/class/:className", async (req, res) => {
    try {
      const { className } = req.params;
      const exams = await storage.getExamsByClass(className);
      res.json(exams);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch exams by class" });
    }
  });

  app.post("/api/exams", async (req, res) => {
    try {
      const validation = insertExamSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid exam data", errors: validation.error.errors });
      }
      
      const exam = await storage.createExam(validation.data);
      res.status(201).json(exam);
    } catch (error) {
      res.status(500).json({ message: "Failed to create exam" });
    }
  });

  // Exam results routes
  app.get("/api/exam-results/exam/:examId", async (req, res) => {
    try {
      const { examId } = req.params;
      const results = await storage.getExamResultsByExam(examId);
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch exam results" });
    }
  });

  app.get("/api/exam-results/student/:studentId", async (req, res) => {
    try {
      const { studentId } = req.params;
      const results = await storage.getExamResultsByStudent(studentId);
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch student results" });
    }
  });

  app.get("/api/exam-results/student/:studentId/exam/:examId", async (req, res) => {
    try {
      const { studentId, examId } = req.params;
      const results = await storage.getStudentResultsByExam(studentId, examId);
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch student exam results" });
    }
  });

  app.post("/api/exam-results", async (req, res) => {
    try {
      const validation = insertExamResultSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid result data", errors: validation.error.errors });
      }
      
      const result = await storage.createExamResult(validation.data);
      res.status(201).json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to create exam result" });
    }
  });

  app.put("/api/exam-results/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const validation = insertExamResultSchema.partial().safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid result data", errors: validation.error.errors });
      }
      
      const result = await storage.updateExamResult(id, validation.data);
      if (!result) {
        return res.status(404).json({ message: "Exam result not found" });
      }
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to update exam result" });
    }
  });

  // Dashboard stats routes
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const totalStudents = (await storage.getStudents()).length;
      const pendingFees = await storage.getStudentsWithPendingFees();
      const feePayments = await storage.getFeePayments();
      
      const currentMonth = new Date().toISOString().slice(0, 7);
      const currentMonthPayments = feePayments.filter(p => p.month === currentMonth);
      const totalCollected = currentMonthPayments.reduce((sum, p) => sum + parseFloat(p.amount), 0);
      
      const feeStructures = await storage.getFeeStructures();
      const totalPending = pendingFees.length * 1250; // Average monthly fee
      
      const classes = await storage.getClasses();
      
      res.json({
        totalStudents,
        pendingFeesAmount: totalPending,
        pendingFeesCount: pendingFees.length,
        totalCollected,
        totalClasses: classes.length,
        recentExam: "Mid Term Exam",
        averageScore: "85.6%"
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
