import { type Student, type InsertStudent, type Class, type InsertClass, type FeeStructure, type InsertFeeStructure, type FeePayment, type InsertFeePayment, type Exam, type InsertExam, type ExamResult, type InsertExamResult } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Students
  getStudent(id: string): Promise<Student | undefined>;
  getStudentByStudentId(studentId: string): Promise<Student | undefined>;
  getStudents(): Promise<Student[]>;
  getStudentsByClass(className: string): Promise<Student[]>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: string, updates: Partial<Student>): Promise<Student | undefined>;
  deleteStudent(id: string): Promise<boolean>;
  searchStudents(query: string): Promise<Student[]>;
  getStudentsWithPendingFees(): Promise<Student[]>;
  getStudentsWithFailedResults(): Promise<Student[]>;

  // Classes
  getClasses(): Promise<Class[]>;
  getClass(name: string): Promise<Class | undefined>;
  createClass(cls: InsertClass): Promise<Class>;
  updateClass(id: string, updates: Partial<Class>): Promise<Class | undefined>;

  // Fee Structures
  getFeeStructures(): Promise<FeeStructure[]>;
  getFeeStructureByClass(className: string): Promise<FeeStructure | undefined>;
  createFeeStructure(feeStructure: InsertFeeStructure): Promise<FeeStructure>;
  updateFeeStructure(id: string, updates: Partial<FeeStructure>): Promise<FeeStructure | undefined>;

  // Fee Payments
  getFeePayments(): Promise<FeePayment[]>;
  getFeePaymentsByStudent(studentId: string): Promise<FeePayment[]>;
  createFeePayment(payment: InsertFeePayment): Promise<FeePayment>;
  getNextReceiptNumber(): Promise<string>;

  // Exams
  getExams(): Promise<Exam[]>;
  getExamsByClass(className: string): Promise<Exam[]>;
  createExam(exam: InsertExam): Promise<Exam>;
  updateExam(id: string, updates: Partial<Exam>): Promise<Exam | undefined>;

  // Exam Results
  getExamResults(): Promise<ExamResult[]>;
  getExamResultsByExam(examId: string): Promise<ExamResult[]>;
  getExamResultsByStudent(studentId: string): Promise<ExamResult[]>;
  createExamResult(result: InsertExamResult): Promise<ExamResult>;
  updateExamResult(id: string, updates: Partial<ExamResult>): Promise<ExamResult | undefined>;
  getStudentResultsByExam(studentId: string, examId: string): Promise<ExamResult[]>;
}

export class MemStorage implements IStorage {
  private students: Map<string, Student> = new Map();
  private classes: Map<string, Class> = new Map();
  private feeStructures: Map<string, FeeStructure> = new Map();
  private feePayments: Map<string, FeePayment> = new Map();
  private exams: Map<string, Exam> = new Map();
  private examResults: Map<string, ExamResult> = new Map();
  private receiptCounter = 1;

  constructor() {
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Initialize default classes
    const defaultClasses = [
      { name: "Nursery", subjects: ["English", "Mathematics", "Drawing", "Games"] },
      { name: "KG", subjects: ["English", "Mathematics", "Science", "Drawing", "Games"] },
      { name: "Grade 1", subjects: ["English", "Mathematics", "Science", "Social Studies", "Drawing"] },
      { name: "Grade 2", subjects: ["English", "Mathematics", "Science", "Social Studies", "Drawing"] },
      { name: "Grade 3", subjects: ["English", "Mathematics", "Science", "Social Studies", "Hindi", "Computer"] },
      { name: "Grade 4", subjects: ["English", "Mathematics", "Science", "Social Studies", "Hindi", "Computer"] },
      { name: "Grade 5", subjects: ["English", "Mathematics", "Science", "Social Studies", "Hindi", "Computer"] },
      { name: "Grade 6", subjects: ["English", "Mathematics", "Science", "Social Studies", "Hindi", "Computer", "Art"] },
      { name: "Grade 7", subjects: ["English", "Mathematics", "Science", "Social Studies", "Hindi", "Computer", "Art"] },
      { name: "Grade 8", subjects: ["English", "Mathematics", "Science", "Social Studies", "Hindi", "Computer", "Art"] },
      { name: "Grade 9", subjects: ["English", "Mathematics", "Science", "Social Studies", "Hindi", "Computer", "Physical Education"] },
      { name: "Grade 10", subjects: ["English", "Mathematics", "Science", "Social Studies", "Hindi", "Computer", "Physical Education"] }
    ];

    defaultClasses.forEach(cls => {
      const id = randomUUID();
      this.classes.set(id, { id, ...cls });
      
      // Add default fee structure for each class
      const feeId = randomUUID();
      let monthlyFee = "1000.00";
      if (cls.name.includes("Grade")) {
        const grade = parseInt(cls.name.split(" ")[1]);
        monthlyFee = grade <= 5 ? "1250.00" : "1500.00";
      }
      
      this.feeStructures.set(feeId, {
        id: feeId,
        class: cls.name,
        admissionFee: "2500.00",
        monthlyFee,
        examFee: "500.00",
        otherFees: []
      });
    });
  }

  // Students
  async getStudent(id: string): Promise<Student | undefined> {
    return this.students.get(id);
  }

  async getStudentByStudentId(studentId: string): Promise<Student | undefined> {
    return Array.from(this.students.values()).find(s => s.studentId === studentId);
  }

  async getStudents(): Promise<Student[]> {
    return Array.from(this.students.values()).filter(s => s.isActive);
  }

  async getStudentsByClass(className: string): Promise<Student[]> {
    return Array.from(this.students.values()).filter(s => s.class === className && s.isActive);
  }

  async createStudent(student: InsertStudent): Promise<Student> {
    const id = randomUUID();
    const newStudent: Student = { ...student, id, isActive: true, email: student.email || null };
    this.students.set(id, newStudent);
    return newStudent;
  }

  async updateStudent(id: string, updates: Partial<Student>): Promise<Student | undefined> {
    const student = this.students.get(id);
    if (student) {
      const updated = { ...student, ...updates };
      this.students.set(id, updated);
      return updated;
    }
    return undefined;
  }

  async deleteStudent(id: string): Promise<boolean> {
    const student = this.students.get(id);
    if (student) {
      student.isActive = false;
      this.students.set(id, student);
      return true;
    }
    return false;
  }

  async searchStudents(query: string): Promise<Student[]> {
    const students = Array.from(this.students.values()).filter(s => s.isActive);
    return students.filter(s => 
      s.name.toLowerCase().includes(query.toLowerCase()) ||
      s.studentId.toLowerCase().includes(query.toLowerCase()) ||
      s.fatherName.toLowerCase().includes(query.toLowerCase())
    );
  }

  async getStudentsWithPendingFees(): Promise<Student[]> {
    // Logic to find students with pending fees
    const allStudents = await this.getStudents();
    const studentsWithPending: Student[] = [];
    
    for (const student of allStudents) {
      const payments = await this.getFeePaymentsByStudent(student.studentId);
      const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM format
      const hasCurrentMonthPayment = payments.some(p => 
        p.month === currentMonth && p.feeType === "Monthly Fee"
      );
      
      if (!hasCurrentMonthPayment) {
        studentsWithPending.push(student);
      }
    }
    
    return studentsWithPending;
  }

  async getStudentsWithFailedResults(): Promise<Student[]> {
    const allStudents = await this.getStudents();
    const studentsWithFailures: Student[] = [];
    
    for (const student of allStudents) {
      const results = await this.getExamResultsByStudent(student.studentId);
      const failedSubjects = results.filter(r => !r.isPassed);
      if (failedSubjects.length >= 3) {
        studentsWithFailures.push(student);
      }
    }
    
    return studentsWithFailures;
  }

  // Classes
  async getClasses(): Promise<Class[]> {
    return Array.from(this.classes.values());
  }

  async getClass(name: string): Promise<Class | undefined> {
    return Array.from(this.classes.values()).find(c => c.name === name);
  }

  async createClass(cls: InsertClass): Promise<Class> {
    const id = randomUUID();
    const newClass: Class = { ...cls, id, subjects: Array.isArray(cls.subjects) ? cls.subjects : [] };
    this.classes.set(id, newClass);
    return newClass;
  }

  async updateClass(id: string, updates: Partial<Class>): Promise<Class | undefined> {
    const cls = this.classes.get(id);
    if (cls) {
      const updated = { ...cls, ...updates };
      this.classes.set(id, updated);
      return updated;
    }
    return undefined;
  }

  // Fee Structures
  async getFeeStructures(): Promise<FeeStructure[]> {
    return Array.from(this.feeStructures.values());
  }

  async getFeeStructureByClass(className: string): Promise<FeeStructure | undefined> {
    return Array.from(this.feeStructures.values()).find(f => f.class === className);
  }

  async createFeeStructure(feeStructure: InsertFeeStructure): Promise<FeeStructure> {
    const id = randomUUID();
    const newFeeStructure: FeeStructure = { ...feeStructure, id, otherFees: Array.isArray(feeStructure.otherFees) ? feeStructure.otherFees : [] };
    this.feeStructures.set(id, newFeeStructure);
    return newFeeStructure;
  }

  async updateFeeStructure(id: string, updates: Partial<FeeStructure>): Promise<FeeStructure | undefined> {
    const feeStructure = this.feeStructures.get(id);
    if (feeStructure) {
      const updated = { ...feeStructure, ...updates };
      this.feeStructures.set(id, updated);
      return updated;
    }
    return undefined;
  }

  // Fee Payments
  async getFeePayments(): Promise<FeePayment[]> {
    return Array.from(this.feePayments.values());
  }

  async getFeePaymentsByStudent(studentId: string): Promise<FeePayment[]> {
    return Array.from(this.feePayments.values()).filter(p => p.studentId === studentId);
  }

  async createFeePayment(payment: InsertFeePayment): Promise<FeePayment> {
    const id = randomUUID();
    const newPayment: FeePayment = { 
      ...payment, 
      id, 
      month: payment.month || null,
      year: payment.year || null,
      remarks: payment.remarks || null
    };
    this.feePayments.set(id, newPayment);
    return newPayment;
  }

  async getNextReceiptNumber(): Promise<string> {
    const prefix = "FEE" + new Date().getFullYear();
    const number = this.receiptCounter.toString().padStart(3, '0');
    this.receiptCounter++;
    return prefix + number;
  }

  // Exams
  async getExams(): Promise<Exam[]> {
    return Array.from(this.exams.values());
  }

  async getExamsByClass(className: string): Promise<Exam[]> {
    return Array.from(this.exams.values()).filter(e => e.class === className);
  }

  async createExam(exam: InsertExam): Promise<Exam> {
    const id = randomUUID();
    const newExam: Exam = { ...exam, id, isCompleted: false };
    this.exams.set(id, newExam);
    return newExam;
  }

  async updateExam(id: string, updates: Partial<Exam>): Promise<Exam | undefined> {
    const exam = this.exams.get(id);
    if (exam) {
      const updated = { ...exam, ...updates };
      this.exams.set(id, updated);
      return updated;
    }
    return undefined;
  }

  // Exam Results
  async getExamResults(): Promise<ExamResult[]> {
    return Array.from(this.examResults.values());
  }

  async getExamResultsByExam(examId: string): Promise<ExamResult[]> {
    return Array.from(this.examResults.values()).filter(r => r.examId === examId);
  }

  async getExamResultsByStudent(studentId: string): Promise<ExamResult[]> {
    return Array.from(this.examResults.values()).filter(r => r.studentId === studentId);
  }

  async createExamResult(result: InsertExamResult): Promise<ExamResult> {
    const id = randomUUID();
    const totalMarks = result.totalMarks || 100;
    const grade = this.calculateGrade(result.marks, totalMarks);
    const isPassed = result.marks >= 40;
    const newResult: ExamResult = { ...result, id, totalMarks, grade, isPassed };
    this.examResults.set(id, newResult);
    return newResult;
  }

  async updateExamResult(id: string, updates: Partial<ExamResult>): Promise<ExamResult | undefined> {
    const result = this.examResults.get(id);
    if (result) {
      const updated = { ...result, ...updates };
      if (updates.marks !== undefined) {
        updated.grade = this.calculateGrade(updated.marks, updated.totalMarks);
        updated.isPassed = updated.marks >= 40;
      }
      this.examResults.set(id, updated);
      return updated;
    }
    return undefined;
  }

  async getStudentResultsByExam(studentId: string, examId: string): Promise<ExamResult[]> {
    return Array.from(this.examResults.values()).filter(r => 
      r.studentId === studentId && r.examId === examId
    );
  }

  private calculateGrade(marks: number, totalMarks: number): string {
    const percentage = (marks / totalMarks) * 100;
    if (percentage >= 90) return "A+";
    if (percentage >= 80) return "A";
    if (percentage >= 70) return "B+";
    if (percentage >= 60) return "B";
    if (percentage >= 50) return "C+";
    if (percentage >= 40) return "C";
    return "F";
  }
}

export const storage = new MemStorage();
