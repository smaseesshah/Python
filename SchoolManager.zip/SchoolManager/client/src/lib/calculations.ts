import { ExamResult } from "@shared/schema";

export function calculateGrade(marks: number, totalMarks: number = 100): string {
  const percentage = (marks / totalMarks) * 100;
  
  if (percentage >= 90) return "A+";
  if (percentage >= 80) return "A";
  if (percentage >= 70) return "B+";
  if (percentage >= 60) return "B";
  if (percentage >= 50) return "C+";
  if (percentage >= 40) return "C";
  return "F";
}

export function calculatePercentage(marks: number, totalMarks: number = 100): number {
  return Math.round((marks / totalMarks) * 100);
}

export function isStudentPassed(results: ExamResult[]): boolean {
  const failedSubjects = results.filter(result => result.marks < 40);
  return failedSubjects.length < 3; // Pass if failed in less than 3 subjects
}

export function calculateTotalMarks(results: ExamResult[]): { 
  obtained: number; 
  total: number; 
  percentage: number 
} {
  const obtained = results.reduce((sum, result) => sum + result.marks, 0);
  const total = results.reduce((sum, result) => sum + result.totalMarks, 0);
  const percentage = total > 0 ? Math.round((obtained / total) * 100) : 0;
  
  return { obtained, total, percentage };
}

export function getOverallGrade(percentage: number): string {
  return calculateGrade(percentage);
}

export function formatCurrency(amount: string | number): string {
  const num = typeof amount === 'string' ? parseFloat(amount) : amount;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(num);
}

export function convertNumberToWords(num: number): string {
  const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
  const teens = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function convertHundreds(num: number): string {
    let result = '';
    
    if (num >= 100) {
      result += ones[Math.floor(num / 100)] + ' Hundred ';
      num %= 100;
    }
    
    if (num >= 20) {
      result += tens[Math.floor(num / 10)] + ' ';
      num %= 10;
    } else if (num >= 10) {
      result += teens[num - 10] + ' ';
      return result;
    }
    
    if (num > 0) {
      result += ones[num] + ' ';
    }
    
    return result;
  }

  if (num === 0) return 'Zero';

  let result = '';
  
  if (num >= 10000000) {
    result += convertHundreds(Math.floor(num / 10000000)) + 'Crore ';
    num %= 10000000;
  }
  
  if (num >= 100000) {
    result += convertHundreds(Math.floor(num / 100000)) + 'Lakh ';
    num %= 100000;
  }
  
  if (num >= 1000) {
    result += convertHundreds(Math.floor(num / 1000)) + 'Thousand ';
    num %= 1000;
  }
  
  if (num > 0) {
    result += convertHundreds(num);
  }
  
  return result.trim() + ' Rupees Only';
}
