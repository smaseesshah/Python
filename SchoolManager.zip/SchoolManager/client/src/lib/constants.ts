export const CLASSES = [
  "Nursery",
  "KG", 
  "Grade 1",
  "Grade 2",
  "Grade 3",
  "Grade 4",
  "Grade 5",
  "Grade 6",
  "Grade 7",
  "Grade 8",
  "Grade 9",
  "Grade 10"
];

export const EXAM_TYPES = [
  { value: "assessment", label: "Assessment" },
  { value: "mid", label: "Mid Exam" },
  { value: "final", label: "Final Exam" }
];

export const PAYMENT_MODES = [
  "Cash",
  "Cheque", 
  "Online Transfer",
  "Card"
];

export const FEE_TYPES = [
  "Admission Fee",
  "Monthly Fee", 
  "Exam Fee",
  "Transport Fee",
  "Library Fee",
  "Sports Fee",
  "Other"
];

export const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];
