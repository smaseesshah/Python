import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, AlertTriangle, ClipboardCheck, Presentation, UserPlus, DollarSign, Edit, Printer, Download, TrendingUp } from "lucide-react";
import { formatCurrency } from "@/lib/calculations";
import { Link } from "wouter";

interface DashboardStats {
  totalStudents: number;
  pendingFeesAmount: number;
  pendingFeesCount: number;
  totalCollected: number;
  totalClasses: number;
  recentExam: string;
  averageScore: string;
}

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard/stats'],
  });

  if (isLoading) {
    return (
      <div>
        <Header 
          title="Dashboard" 
          description="Overview of school management metrics" 
        />
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-20 bg-muted rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <Header 
        title="Dashboard" 
        description="Overview of school management metrics" 
      />
      
      <div className="p-6">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Students</p>
                  <p className="text-3xl font-bold text-foreground" data-testid="stat-total-students">
                    {stats?.totalStudents ?? 0}
                  </p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Users className="text-blue-600 text-lg" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <span className="text-green-600 font-medium">Active</span>
                <span className="text-muted-foreground ml-1">enrollment</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Pending Fees</p>
                  <p className="text-3xl font-bold text-foreground" data-testid="stat-pending-fees">
                    {formatCurrency(stats?.pendingFeesAmount ?? 0)}
                  </p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <AlertTriangle className="text-orange-600 text-lg" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <span className="text-red-600 font-medium" data-testid="pending-fees-count">
                  {stats?.pendingFeesCount ?? 0} students
                </span>
                <span className="text-muted-foreground ml-1">with overdue fees</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Recent Exams</p>
                  <p className="text-3xl font-bold text-foreground" data-testid="stat-recent-exam">
                    {stats?.recentExam ?? "N/A"}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <ClipboardCheck className="text-green-600 text-lg" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <span className="text-green-600 font-medium" data-testid="average-score">
                  {stats?.averageScore ?? "0%"}
                </span>
                <span className="text-muted-foreground ml-1">average score</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Classes</p>
                  <p className="text-3xl font-bold text-foreground" data-testid="stat-total-classes">
                    {stats?.totalClasses ?? 0}
                  </p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Presentation className="text-purple-600 text-lg" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <span className="text-muted-foreground">Nursery to Grade 10</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity & Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Fee Collection Overview */}
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-foreground">Fee Collection</h3>
                <Link href="/fees">
                  <Button variant="ghost" size="sm">
                    View All
                  </Button>
                </Link>
              </div>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg">
                  <div>
                    <p className="font-medium text-green-900">Total Collected</p>
                    <p className="text-sm text-green-700">This month</p>
                  </div>
                  <p className="text-xl font-bold text-green-900" data-testid="total-collected">
                    {formatCurrency(stats?.totalCollected ?? 0)}
                  </p>
                </div>
                <div className="flex justify-between items-center p-4 bg-orange-50 rounded-lg">
                  <div>
                    <p className="font-medium text-orange-900">Pending Amount</p>
                    <p className="text-sm text-orange-700">{stats?.pendingFeesCount ?? 0} students</p>
                  </div>
                  <p className="text-xl font-bold text-orange-900">
                    {formatCurrency(stats?.pendingFeesAmount ?? 0)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Links */}
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-foreground">Quick Navigation</h3>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Link href="/students">
                  <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2 w-full" data-testid="quick-nav-students">
                    <Users className="w-6 h-6" />
                    <span className="text-sm">Manage Students</span>
                  </Button>
                </Link>
                <Link href="/fees">
                  <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2 w-full" data-testid="quick-nav-fees">
                    <DollarSign className="w-6 h-6" />
                    <span className="text-sm">Fee Management</span>
                  </Button>
                </Link>
                <Link href="/exams">
                  <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2 w-full" data-testid="quick-nav-exams">
                    <ClipboardCheck className="w-6 h-6" />
                    <span className="text-sm">Exam Results</span>
                  </Button>
                </Link>
                <Link href="/reports">
                  <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2 w-full" data-testid="quick-nav-reports">
                    <Printer className="w-6 h-6" />
                    <span className="text-sm">Print Reports</span>
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <Link href="/students">
                <Button 
                  variant="outline" 
                  className="h-auto p-4 flex flex-col items-center gap-2 w-full hover:bg-accent transition-colors"
                  data-testid="action-add-student"
                >
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <UserPlus className="text-blue-600" />
                  </div>
                  <span className="text-sm font-medium">Add Student</span>
                </Button>
              </Link>
              
              <Link href="/fees">
                <Button 
                  variant="outline" 
                  className="h-auto p-4 flex flex-col items-center gap-2 w-full hover:bg-accent transition-colors"
                  data-testid="action-record-payment"
                >
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <DollarSign className="text-green-600" />
                  </div>
                  <span className="text-sm font-medium">Record Payment</span>
                </Button>
              </Link>
              
              <Link href="/exams">
                <Button 
                  variant="outline" 
                  className="h-auto p-4 flex flex-col items-center gap-2 w-full hover:bg-accent transition-colors"
                  data-testid="action-enter-marks"
                >
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Edit className="text-purple-600" />
                  </div>
                  <span className="text-sm font-medium">Enter Marks</span>
                </Button>
              </Link>
              
              <Link href="/reports">
                <Button 
                  variant="outline" 
                  className="h-auto p-4 flex flex-col items-center gap-2 w-full hover:bg-accent transition-colors"
                  data-testid="action-print-reports"
                >
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <Printer className="text-orange-600" />
                  </div>
                  <span className="text-sm font-medium">Print Reports</span>
                </Button>
              </Link>
              
              <Button 
                variant="outline" 
                className="h-auto p-4 flex flex-col items-center gap-2 w-full hover:bg-accent transition-colors"
                data-testid="action-backup-data"
              >
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <Download className="text-indigo-600" />
                </div>
                <span className="text-sm font-medium">Backup Data</span>
              </Button>
              
              <Button 
                variant="outline" 
                className="h-auto p-4 flex flex-col items-center gap-2 w-full hover:bg-accent transition-colors"
                data-testid="action-class-promotion"
              >
                <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="text-teal-600" />
                </div>
                <span className="text-sm font-medium">Class Promotion</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
