import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Edit, Eye, FileText, Search, CheckCircle2, XCircle } from "lucide-react";
import { Exam, ExamResult, Student } from "@shared/schema";
import { CLASSES, EXAM_TYPES } from "@/lib/constants";
import { calculateGrade, calculatePercentage, isStudentPassed, getOverallGrade } from "@/lib/calculations";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import MarksForm from "@/components/forms/marks-form";
import ReportCardTemplate from "@/components/print/report-card-template";

export default function Exams() {
  const [selectedClass, setSelectedClass] = useState<string>("all");
  const [selectedExamType, setSelectedExamType] = useState<string>("all");
  const [isCreateExamOpen, setIsCreateExamOpen] = useState(false);
  const [isMarksFormOpen, setIsMarksFormOpen] = useState(false);
  const [selectedExam, setSelectedExam] = useState<Exam | null>(null);
  const [selectedStudentForReport, setSelectedStudentForReport] = useState<Student | null>(null);
  const { toast } = useToast();

  const { data: exams = [], isLoading: examsLoading } = useQuery<Exam[]>({
    queryKey: ['/api/exams'],
  });

  const { data: students = [] } = useQuery<Student[]>({
    queryKey: ['/api/students'],
  });

  const { data: examResults = [] } = useQuery<ExamResult[]>({
    queryKey: ['/api/exam-results'],
  });

  const createExamMutation = useMutation({
    mutationFn: async (examData: { name: string; type: string; class: string; year: string }) => {
      const response = await apiRequest('POST', '/api/exams', examData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/exams'] });
      toast({
        title: "Success",
        description: "Exam created successfully",
      });
      setIsCreateExamOpen(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create exam",
        variant: "destructive",
      });
    }
  });

  const filteredExams = exams.filter((exam) => {
    const matchesClass = selectedClass === "all" || exam.class === selectedClass;
    const matchesType = selectedExamType === "all" || exam.type === selectedExamType;
    return matchesClass && matchesType;
  });

  const getExamResults = (examId: string) => {
    return examResults.filter(result => result.examId === examId);
  };

  const getStudentResults = (studentId: string, examId: string) => {
    return examResults.filter(result => result.studentId === studentId && result.examId === examId);
  };

  const getExamStats = (examId: string) => {
    const results = getExamResults(examId);
    if (results.length === 0) return { total: 0, passed: 0, failed: 0, percentage: 0 };
    
    const studentsWithResults = new Set(results.map(r => r.studentId));
    const passedStudents = Array.from(studentsWithResults).filter(studentId => {
      const studentResults = results.filter(r => r.studentId === studentId);
      return isStudentPassed(studentResults);
    });
    
    return {
      total: studentsWithResults.size,
      passed: passedStudents.length,
      failed: studentsWithResults.size - passedStudents.length,
      percentage: Math.round((passedStudents.length / studentsWithResults.size) * 100) || 0
    };
  };

  const handleCreateExam = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const examData = {
      name: formData.get('name') as string,
      type: formData.get('type') as string,
      class: formData.get('class') as string,
      year: new Date().getFullYear().toString(),
    };
    createExamMutation.mutate(examData);
  };

  const handlePrintReportCard = (student: Student) => {
    setSelectedStudentForReport(student);
    setTimeout(() => {
      window.print();
    }, 100);
  };

  return (
    <div>
      <Header 
        title="Exams & Results" 
        description="Manage exams, enter marks, and view results"
      >
        <Dialog open={isCreateExamOpen} onOpenChange={setIsCreateExamOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-exam">
              <Plus className="mr-2 h-4 w-4" />Create Exam
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Exam</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateExam} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Exam Name</label>
                <Input name="name" placeholder="e.g., Mid Term Exam - Math" required data-testid="input-exam-name" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Exam Type</label>
                <Select name="type" required>
                  <SelectTrigger data-testid="select-exam-type">
                    <SelectValue placeholder="Select exam type" />
                  </SelectTrigger>
                  <SelectContent>
                    {EXAM_TYPES.map(type => (
                      <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Class</label>
                <Select name="class" required>
                  <SelectTrigger data-testid="select-exam-class">
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    {CLASSES.map(cls => (
                      <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsCreateExamOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createExamMutation.isPending} data-testid="button-save-exam">
                  {createExamMutation.isPending ? "Creating..." : "Create Exam"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </Header>

      <div className="p-6">
        <Tabs defaultValue="exams" className="space-y-6">
          <TabsList>
            <TabsTrigger value="exams" data-testid="tab-exams">Exams</TabsTrigger>
            <TabsTrigger value="results" data-testid="tab-results">Results</TabsTrigger>
            <TabsTrigger value="reports" data-testid="tab-exam-reports">Report Cards</TabsTrigger>
          </TabsList>

          <TabsContent value="exams">
            {/* Filters */}
            <Card className="mb-6">
              <CardContent className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1">Class</label>
                    <Select value={selectedClass} onValueChange={setSelectedClass}>
                      <SelectTrigger data-testid="select-class-filter">
                        <SelectValue placeholder="All Classes" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Classes</SelectItem>
                        {CLASSES.map(cls => (
                          <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1">Exam Type</label>
                    <Select value={selectedExamType} onValueChange={setSelectedExamType}>
                      <SelectTrigger data-testid="select-type-filter">
                        <SelectValue placeholder="All Types" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Types</SelectItem>
                        {EXAM_TYPES.map(type => (
                          <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Exams List */}
            <Card>
              <CardHeader>
                <CardTitle>Exam List</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {examsLoading ? (
                  <div className="p-6">
                    <div className="animate-pulse space-y-4">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <div key={i} className="h-12 bg-muted rounded"></div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Exam Name</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Class</TableHead>
                          <TableHead>Year</TableHead>
                          <TableHead>Results Entered</TableHead>
                          <TableHead>Pass Rate</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredExams.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                              No exams found
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredExams.map((exam) => {
                            const stats = getExamStats(exam.id);
                            const examType = EXAM_TYPES.find(t => t.value === exam.type);
                            return (
                              <TableRow key={exam.id} className="table-row" data-testid={`row-exam-${exam.id}`}>
                                <TableCell className="font-medium" data-testid={`text-exam-name-${exam.id}`}>
                                  {exam.name}
                                </TableCell>
                                <TableCell>
                                  <Badge variant="outline" data-testid={`badge-exam-type-${exam.id}`}>
                                    {examType?.label}
                                  </Badge>
                                </TableCell>
                                <TableCell data-testid={`text-exam-class-${exam.id}`}>{exam.class}</TableCell>
                                <TableCell data-testid={`text-exam-year-${exam.id}`}>{exam.year}</TableCell>
                                <TableCell data-testid={`text-results-count-${exam.id}`}>
                                  {stats.total > 0 ? `${stats.total} students` : "No results"}
                                </TableCell>
                                <TableCell data-testid={`text-pass-rate-${exam.id}`}>
                                  {stats.total > 0 ? `${stats.percentage}%` : "N/A"}
                                </TableCell>
                                <TableCell>
                                  <div className="flex space-x-2">
                                    <Dialog>
                                      <DialogTrigger asChild>
                                        <Button 
                                          variant="ghost" 
                                          size="sm"
                                          onClick={() => setSelectedExam(exam)}
                                          data-testid={`button-enter-marks-${exam.id}`}
                                        >
                                          <Edit className="h-4 w-4" />
                                        </Button>
                                      </DialogTrigger>
                                      <DialogContent className="max-w-4xl">
                                        <DialogHeader>
                                          <DialogTitle>Enter Marks - {exam.name}</DialogTitle>
                                        </DialogHeader>
                                        {selectedExam && (
                                          <MarksForm exam={selectedExam} onSuccess={() => setSelectedExam(null)} />
                                        )}
                                      </DialogContent>
                                    </Dialog>
                                    
                                    <Button 
                                      variant="ghost" 
                                      size="sm"
                                      data-testid={`button-view-results-${exam.id}`}
                                    >
                                      <Eye className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            );
                          })
                        )}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="results">
            <Card>
              <CardHeader>
                <CardTitle>Exam Results Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredExams.map((exam) => {
                    const stats = getExamStats(exam.id);
                    const examType = EXAM_TYPES.find(t => t.value === exam.type);
                    
                    return (
                      <Card key={exam.id} data-testid={`card-exam-stats-${exam.id}`}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-3">
                            <h3 className="font-semibold text-sm" data-testid={`text-exam-title-${exam.id}`}>
                              {exam.name}
                            </h3>
                            <Badge variant="outline">
                              {examType?.label}
                            </Badge>
                          </div>
                          
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>Total Students:</span>
                              <span className="font-medium" data-testid={`stat-total-${exam.id}`}>
                                {stats.total}
                              </span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="flex items-center">
                                <CheckCircle2 className="w-3 h-3 text-green-600 mr-1" />
                                Passed:
                              </span>
                              <span className="font-medium text-green-600" data-testid={`stat-passed-${exam.id}`}>
                                {stats.passed}
                              </span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="flex items-center">
                                <XCircle className="w-3 h-3 text-red-600 mr-1" />
                                Failed:
                              </span>
                              <span className="font-medium text-red-600" data-testid={`stat-failed-${exam.id}`}>
                                {stats.failed}
                              </span>
                            </div>
                            <div className="flex justify-between text-sm font-semibold">
                              <span>Pass Rate:</span>
                              <span data-testid={`stat-pass-rate-${exam.id}`}>
                                {stats.percentage}%
                              </span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports">
            <Card>
              <CardHeader>
                <CardTitle>Student Report Cards</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <Select value={selectedClass} onValueChange={setSelectedClass}>
                    <SelectTrigger className="w-48" data-testid="select-report-class">
                      <SelectValue placeholder="Select Class" />
                    </SelectTrigger>
                    <SelectContent>
                      {CLASSES.map(cls => (
                        <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {students
                    .filter(student => selectedClass === "all" || student.class === selectedClass)
                    .map((student) => {
                      const studentResults = examResults.filter(r => r.studentId === student.studentId);
                      const hasResults = studentResults.length > 0;
                      
                      return (
                        <Card key={student.id} data-testid={`card-student-report-${student.studentId}`}>
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <h3 className="font-semibold" data-testid={`text-report-student-name-${student.studentId}`}>
                                  {student.name}
                                </h3>
                                <p className="text-sm text-muted-foreground">
                                  {student.studentId} • {student.class}
                                </p>
                                {hasResults && (
                                  <p className="text-xs text-muted-foreground">
                                    {studentResults.length} exam results
                                  </p>
                                )}
                              </div>
                              <Button 
                                variant="outline" 
                                size="sm"
                                disabled={!hasResults}
                                onClick={() => handlePrintReportCard(student)}
                                data-testid={`button-print-report-${student.studentId}`}
                              >
                                <FileText className="h-4 w-4" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Report Card Template for Printing */}
      {selectedStudentForReport && (
        <div className="hidden print:block">
          <ReportCardTemplate student={selectedStudentForReport} />
        </div>
      )}
    </div>
  );
}
