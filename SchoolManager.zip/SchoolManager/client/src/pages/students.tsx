import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Download, Eye, Edit, Trash2, Search } from "lucide-react";
import { Student } from "@shared/schema";
import { CLASSES } from "@/lib/constants";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import StudentForm from "@/components/forms/student-form";

export default function Students() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedClass, setSelectedClass] = useState<string>("all");
  const [feeFilter, setFeeFilter] = useState<string>("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const { toast } = useToast();

  const { data: students = [], isLoading } = useQuery<Student[]>({
    queryKey: ['/api/students'],
  });

  const { data: pendingFeeStudents = [] } = useQuery<Student[]>({
    queryKey: ['/api/students/pending-fees'],
  });

  const deleteStudentMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/students/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete student');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/students'] });
      toast({
        title: "Success",
        description: "Student deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete student",
        variant: "destructive",
      });
    }
  });

  const filteredStudents = students.filter((student) => {
    const matchesSearch = !searchQuery || 
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.fatherName.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesClass = selectedClass === "all" || student.class === selectedClass;
    
    const matchesFeeFilter = feeFilter === "all" || 
      (feeFilter === "pending" && pendingFeeStudents.some(p => p.id === student.id)) ||
      (feeFilter === "paid" && !pendingFeeStudents.some(p => p.id === student.id));
    
    return matchesSearch && matchesClass && matchesFeeFilter;
  });

  const getFeeStatus = (studentId: string): { status: string; variant: "default" | "secondary" | "destructive" | "outline" } => {
    const hasPendingFees = pendingFeeStudents.some(p => p.id === studentId);
    return hasPendingFees 
      ? { status: "Pending", variant: "destructive" }
      : { status: "Paid", variant: "default" };
  };

  const handleDelete = (student: Student) => {
    if (confirm(`Are you sure you want to delete ${student.name}?`)) {
      deleteStudentMutation.mutate(student.id);
    }
  };

  return (
    <div>
      <Header 
        title="Student Management" 
        description="Add, edit, and manage student records"
      >
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-student">
              <Plus className="mr-2 h-4 w-4" />Add Student
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Student</DialogTitle>
            </DialogHeader>
            <StudentForm 
              onSuccess={() => setIsAddDialogOpen(false)} 
            />
          </DialogContent>
        </Dialog>
        
        <Button variant="outline" data-testid="button-export-students">
          <Download className="mr-2 h-4 w-4" />Export
        </Button>
      </Header>

      <div className="p-6">
        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Search Student</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input 
                    placeholder="Student ID or Name" 
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    data-testid="input-search-student"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Class</label>
                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger data-testid="select-class-filter">
                    <SelectValue placeholder="All Classes" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Classes</SelectItem>
                    {CLASSES.map(cls => (
                      <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Fee Status</label>
                <Select value={feeFilter} onValueChange={setFeeFilter}>
                  <SelectTrigger data-testid="select-fee-filter">
                    <SelectValue placeholder="All Students" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Students</SelectItem>
                    <SelectItem value="paid">Paid</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-end">
                <Button 
                  className="w-full"
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedClass("all");
                    setFeeFilter("all");
                  }}
                  data-testid="button-reset-filters"
                >
                  <Search className="mr-2 h-4 w-4" />Reset Filters
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Students Table */}
        <Card>
          <CardContent className="p-0">
            <div className="px-6 py-4 border-b border-border">
              <h3 className="text-lg font-semibold text-foreground">Student Records</h3>
              <p className="text-sm text-muted-foreground">
                Showing {filteredStudents.length} of {students.length} students
              </p>
            </div>
            
            {isLoading ? (
              <div className="p-6">
                <div className="animate-pulse space-y-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="h-12 bg-muted rounded"></div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Student ID</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Class</TableHead>
                      <TableHead>Father's Name</TableHead>
                      <TableHead>Fee Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredStudents.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                          No students found matching your criteria
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredStudents.map((student) => {
                        const feeStatus = getFeeStatus(student.id);
                        return (
                          <TableRow key={student.id} className="table-row" data-testid={`row-student-${student.studentId}`}>
                            <TableCell className="font-medium" data-testid={`text-student-id-${student.studentId}`}>
                              {student.studentId}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                                  <span className="text-primary font-medium text-xs">
                                    {student.name.split(' ').map(n => n[0]).join('').substring(0, 2)}
                                  </span>
                                </div>
                                <span className="font-medium" data-testid={`text-student-name-${student.studentId}`}>
                                  {student.name}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell data-testid={`text-student-class-${student.studentId}`}>
                              {student.class}
                            </TableCell>
                            <TableCell data-testid={`text-father-name-${student.studentId}`}>
                              {student.fatherName}
                            </TableCell>
                            <TableCell>
                              <Badge variant={feeStatus.variant} data-testid={`badge-fee-status-${student.studentId}`}>
                                {feeStatus.status}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  data-testid={`button-view-${student.studentId}`}
                                >
                                  <Eye className="h-4 w-4" />
                                </Button>
                                
                                <Dialog>
                                  <DialogTrigger asChild>
                                    <Button 
                                      variant="ghost" 
                                      size="sm"
                                      onClick={() => setEditingStudent(student)}
                                      data-testid={`button-edit-${student.studentId}`}
                                    >
                                      <Edit className="h-4 w-4" />
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="max-w-2xl">
                                    <DialogHeader>
                                      <DialogTitle>Edit Student</DialogTitle>
                                    </DialogHeader>
                                    {editingStudent && (
                                      <StudentForm 
                                        student={editingStudent}
                                        onSuccess={() => setEditingStudent(null)} 
                                      />
                                    )}
                                  </DialogContent>
                                </Dialog>
                                
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  onClick={() => handleDelete(student)}
                                  disabled={deleteStudentMutation.isPending}
                                  data-testid={`button-delete-${student.studentId}`}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
