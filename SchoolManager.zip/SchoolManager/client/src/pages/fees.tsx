import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Printer, CheckCircle, Clock, AlertTriangle, Eye } from "lucide-react";
import { FeePayment, Student } from "@shared/schema";
import { formatCurrency } from "@/lib/calculations";
import { CLASSES } from "@/lib/constants";
import PaymentForm from "@/components/forms/payment-form";
import ReceiptTemplate from "@/components/print/receipt-template";
import { useToast } from "@/hooks/use-toast";

export default function Fees() {
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedClass, setSelectedClass] = useState<string>("all");
  const [selectedReceipt, setSelectedReceipt] = useState<FeePayment | null>(null);
  const { toast } = useToast();

  const { data: payments = [], isLoading } = useQuery<FeePayment[]>({
    queryKey: ['/api/fee-payments'],
  });

  const { data: students = [] } = useQuery<Student[]>({
    queryKey: ['/api/students'],
  });

  const { data: pendingFeeStudents = [] } = useQuery<Student[]>({
    queryKey: ['/api/students/pending-fees'],
  });

  const filteredPayments = payments.filter((payment) => {
    const student = students.find(s => s.studentId === payment.studentId);
    const matchesSearch = !searchQuery || 
      student?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.studentId.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesClass = selectedClass === "all" || student?.class === selectedClass;
    
    return matchesSearch && matchesClass;
  });

  // Calculate statistics
  const currentMonth = new Date().toISOString().slice(0, 7);
  const currentMonthPayments = payments.filter(p => p.month === currentMonth);
  const totalCollected = currentMonthPayments.reduce((sum, p) => sum + parseFloat(p.amount), 0);
  const avgMonthlyFee = 1250; // Average monthly fee
  const pendingAmount = pendingFeeStudents.length * avgMonthlyFee;
  const overdueStudents = pendingFeeStudents.filter(s => {
    // Consider students with no payment in last 2 months as overdue
    const twoMonthsAgo = new Date();
    twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);
    const twoMonthsAgoStr = twoMonthsAgo.toISOString().slice(0, 7);
    
    const recentPayments = payments.filter(p => 
      p.studentId === s.studentId && 
      p.month && 
      p.month >= twoMonthsAgoStr
    );
    return recentPayments.length === 0;
  });

  const getStudentName = (studentId: string): string => {
    const student = students.find(s => s.studentId === studentId);
    return student?.name || "Unknown Student";
  };

  const getStudentClass = (studentId: string): string => {
    const student = students.find(s => s.studentId === studentId);
    return student?.class || "Unknown";
  };

  const handlePrint = (payment: FeePayment) => {
    setSelectedReceipt(payment);
    setTimeout(() => {
      window.print();
    }, 100);
  };

  return (
    <div>
      <Header 
        title="Fee Management" 
        description="Track payments and manage fee structures"
      >
        <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-record-payment">
              <Plus className="mr-2 h-4 w-4" />Record Payment
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Record Fee Payment</DialogTitle>
            </DialogHeader>
            <PaymentForm 
              onSuccess={() => setIsPaymentDialogOpen(false)} 
            />
          </DialogContent>
        </Dialog>
        
        <Button variant="outline" data-testid="button-print-receipts">
          <Printer className="mr-2 h-4 w-4" />Print Receipts
        </Button>
      </Header>

      <div className="p-6">
        {/* Fee Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Collected</p>
                  <p className="text-2xl font-bold text-green-600" data-testid="stat-total-collected">
                    {formatCurrency(totalCollected)}
                  </p>
                </div>
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="text-green-600" />
                </div>
              </div>
              <p className="text-sm text-muted-foreground mt-2">This month</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Pending Amount</p>
                  <p className="text-2xl font-bold text-orange-600" data-testid="stat-pending-amount">
                    {formatCurrency(pendingAmount)}
                  </p>
                </div>
                <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Clock className="text-orange-600" />
                </div>
              </div>
              <p className="text-sm text-muted-foreground mt-2" data-testid="stat-pending-count">
                {pendingFeeStudents.length} students
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Overdue Amount</p>
                  <p className="text-2xl font-bold text-red-600" data-testid="stat-overdue-amount">
                    {formatCurrency(overdueStudents.length * avgMonthlyFee)}
                  </p>
                </div>
                <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                  <AlertTriangle className="text-red-600" />
                </div>
              </div>
              <p className="text-sm text-muted-foreground mt-2" data-testid="stat-overdue-count">
                {overdueStudents.length} students
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Payment Records */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Recent Payments</CardTitle>
              <div className="flex space-x-3">
                <Input 
                  placeholder="Search student..." 
                  className="w-48"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  data-testid="input-search-payments"
                />
                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger className="w-40" data-testid="select-class-filter">
                    <SelectValue placeholder="All Classes" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Classes</SelectItem>
                    {CLASSES.map(cls => (
                      <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-6">
                <div className="animate-pulse space-y-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="h-12 bg-muted rounded"></div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Receipt No.</TableHead>
                      <TableHead>Student</TableHead>
                      <TableHead>Class</TableHead>
                      <TableHead>Fee Type</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPayments.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                          No payment records found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredPayments.slice(0, 20).map((payment) => (
                        <TableRow key={payment.id} className="table-row" data-testid={`row-payment-${payment.receiptNumber}`}>
                          <TableCell className="font-medium" data-testid={`text-receipt-${payment.receiptNumber}`}>
                            {payment.receiptNumber}
                          </TableCell>
                          <TableCell data-testid={`text-student-${payment.receiptNumber}`}>
                            {getStudentName(payment.studentId)}
                          </TableCell>
                          <TableCell data-testid={`text-class-${payment.receiptNumber}`}>
                            {getStudentClass(payment.studentId)}
                          </TableCell>
                          <TableCell data-testid={`text-fee-type-${payment.receiptNumber}`}>
                            {payment.feeType}
                          </TableCell>
                          <TableCell className="font-medium text-green-600" data-testid={`text-amount-${payment.receiptNumber}`}>
                            {formatCurrency(payment.amount)}
                          </TableCell>
                          <TableCell data-testid={`text-date-${payment.receiptNumber}`}>
                            {new Date(payment.paymentDate).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => setSelectedReceipt(payment)}
                                data-testid={`button-view-${payment.receiptNumber}`}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => handlePrint(payment)}
                                data-testid={`button-print-${payment.receiptNumber}`}
                              >
                                <Printer className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Receipt Template for Printing */}
      {selectedReceipt && (
        <div className="hidden print:block">
          <ReceiptTemplate payment={selectedReceipt} />
        </div>
      )}
    </div>
  );
}
