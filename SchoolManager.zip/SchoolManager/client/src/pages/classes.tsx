import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Class } from "@shared/schema";
import { Book, Users } from "lucide-react";

export default function Classes() {
  const { data: classes = [], isLoading } = useQuery<Class[]>({
    queryKey: ['/api/classes'],
  });

  if (isLoading) {
    return (
      <div>
        <Header 
          title="Classes & Subjects" 
          description="Manage class structure and subject assignments" 
        />
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-32 bg-muted rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <Header 
        title="Classes & Subjects" 
        description="Manage class structure and subject assignments" 
      />
      
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {classes.map((cls) => (
            <Card key={cls.id} className="hover:shadow-lg transition-shadow" data-testid={`card-class-${cls.name.toLowerCase().replace(/\s+/g, '-')}`}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center">
                    <Users className="mr-2 h-5 w-5 text-primary" />
                    {cls.name}
                  </span>
                  <Badge variant="secondary" data-testid={`badge-subject-count-${cls.name.toLowerCase().replace(/\s+/g, '-')}`}>
                    {cls.subjects.length} subjects
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Book className="mr-2 h-4 w-4" />
                    Subjects:
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {cls.subjects.map((subject) => (
                      <Badge 
                        key={subject} 
                        variant="outline"
                        data-testid={`badge-subject-${cls.name.toLowerCase().replace(/\s+/g, '-')}-${subject.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        {subject}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Class Structure Overview */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>School Structure Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600" data-testid="stat-nursery-kg-count">2</div>
                <div className="text-sm text-blue-700">Early Years</div>
                <div className="text-xs text-blue-600">Nursery - KG</div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600" data-testid="stat-primary-count">5</div>
                <div className="text-sm text-green-700">Primary</div>
                <div className="text-xs text-green-600">Grade 1 - 5</div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <div className="text-2xl font-bold text-purple-600" data-testid="stat-middle-count">3</div>
                <div className="text-sm text-purple-700">Middle School</div>
                <div className="text-xs text-purple-600">Grade 6 - 8</div>
              </div>
              <div className="text-center p-4 bg-orange-50 rounded-lg">
                <div className="text-2xl font-bold text-orange-600" data-testid="stat-high-count">2</div>
                <div className="text-sm text-orange-700">High School</div>
                <div className="text-xs text-orange-600">Grade 9 - 10</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
