import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Download, Printer, BarChart3, Users, DollarSign, TrendingUp } from "lucide-react";
import { Student, FeePayment, ExamResult, Exam } from "@shared/schema";
import { CLASSES } from "@/lib/constants";
import { formatCurrency, calculateTotalMarks, isStudentPassed } from "@/lib/calculations";
import ReportCardTemplate from "@/components/print/report-card-template";
import ReceiptTemplate from "@/components/print/receipt-template";

export default function Reports() {
  const [selectedClass, setSelectedClass] = useState<string>("all");
  const [selectedMonth, setSelectedMonth] = useState<string>(new Date().toISOString().slice(0, 7));
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [selectedPayment, setSelectedPayment] = useState<FeePayment | null>(null);
  const [reportType, setReportType] = useState<string>("report-card");

  const { data: students = [] } = useQuery<Student[]>({
    queryKey: ['/api/students'],
  });

  const { data: feePayments = [] } = useQuery<FeePayment[]>({
    queryKey: ['/api/fee-payments'],
  });

  const { data: examResults = [] } = useQuery<ExamResult[]>({
    queryKey: ['/api/exam-results'],
  });

  const { data: exams = [] } = useQuery<Exam[]>({
    queryKey: ['/api/exams'],
  });

  const { data: pendingFeeStudents = [] } = useQuery<Student[]>({
    queryKey: ['/api/students/pending-fees'],
  });

  const filteredStudents = students.filter(student => 
    selectedClass === "all" || student.class === selectedClass
  );

  const monthlyPayments = feePayments.filter(payment => 
    payment.month === selectedMonth
  );

  const classWiseStats = CLASSES.map(className => {
    const classStudents = students.filter(s => s.class === className);
    const classPayments = feePayments.filter(p => {
      const student = students.find(s => s.studentId === p.studentId);
      return student?.class === className && p.month === selectedMonth;
    });
    
    const collected = classPayments.reduce((sum, p) => sum + parseFloat(p.amount), 0);
    const pendingCount = pendingFeeStudents.filter(s => s.class === className).length;
    
    return {
      class: className,
      totalStudents: classStudents.length,
      collected,
      pendingCount,
      collectionRate: classStudents.length > 0 ? ((classStudents.length - pendingCount) / classStudents.length * 100) : 0
    };
  });

  const examPerformanceStats = exams.map(exam => {
    const examResultsForExam = examResults.filter(r => r.examId === exam.id);
    const studentsWithResults = new Set(examResultsForExam.map(r => r.studentId));
    
    const passedStudents = Array.from(studentsWithResults).filter(studentId => {
      const studentResults = examResultsForExam.filter(r => r.studentId === studentId);
      return isStudentPassed(studentResults);
    });
    
    return {
      exam,
      totalStudents: studentsWithResults.size,
      passedStudents: passedStudents.length,
      passRate: studentsWithResults.size > 0 ? (passedStudents.length / studentsWithResults.size * 100) : 0
    };
  });

  const handlePrintReport = (student: Student) => {
    setSelectedStudent(student);
    setReportType("report-card");
    setTimeout(() => {
      window.print();
    }, 100);
  };

  const handlePrintReceipt = (payment: FeePayment) => {
    setSelectedPayment(payment);
    setReportType("receipt");
    setTimeout(() => {
      window.print();
    }, 100);
  };

  const handlePrintClassReport = () => {
    setTimeout(() => {
      window.print();
    }, 100);
  };

  return (
    <div>
      <Header 
        title="Reports" 
        description="Generate and print various school reports"
      >
        <Button onClick={handlePrintClassReport} data-testid="button-print-current-report">
          <Printer className="mr-2 h-4 w-4" />Print Current View
        </Button>
        <Button variant="outline" data-testid="button-export-reports">
          <Download className="mr-2 h-4 w-4" />Export Data
        </Button>
      </Header>

      <div className="p-6">
        <Tabs defaultValue="student-reports" className="space-y-6">
          <TabsList>
            <TabsTrigger value="student-reports" data-testid="tab-student-reports">Student Reports</TabsTrigger>
            <TabsTrigger value="fee-reports" data-testid="tab-fee-reports">Fee Reports</TabsTrigger>
            <TabsTrigger value="exam-reports" data-testid="tab-exam-reports">Exam Reports</TabsTrigger>
            <TabsTrigger value="summary" data-testid="tab-summary-reports">Summary</TabsTrigger>
          </TabsList>

          <TabsContent value="student-reports">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Student Report Cards</CardTitle>
                  <Select value={selectedClass} onValueChange={setSelectedClass}>
                    <SelectTrigger className="w-48" data-testid="select-report-class">
                      <SelectValue placeholder="Select Class" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Classes</SelectItem>
                      {CLASSES.map(cls => (
                        <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Student ID</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Class</TableHead>
                        <TableHead>Exam Results</TableHead>
                        <TableHead>Overall Performance</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredStudents.map((student) => {
                        const studentResults = examResults.filter(r => r.studentId === student.studentId);
                        const hasResults = studentResults.length > 0;
                        
                        let overallStatus = "No Results";
                        if (hasResults) {
                          // Group by exam and check pass/fail for each
                          const resultsByExam = studentResults.reduce((acc, result) => {
                            if (!acc[result.examId]) acc[result.examId] = [];
                            acc[result.examId].push(result);
                            return acc;
                          }, {} as Record<string, ExamResult[]>);
                          
                          const examStatuses = Object.values(resultsByExam).map(results => 
                            isStudentPassed(results)
                          );
                          
                          const passedExams = examStatuses.filter(Boolean).length;
                          const totalExams = examStatuses.length;
                          
                          overallStatus = `${passedExams}/${totalExams} Exams Passed`;
                        }
                        
                        return (
                          <TableRow key={student.id} data-testid={`row-student-report-${student.studentId}`}>
                            <TableCell className="font-medium" data-testid={`text-student-id-${student.studentId}`}>
                              {student.studentId}
                            </TableCell>
                            <TableCell data-testid={`text-student-name-${student.studentId}`}>
                              {student.name}
                            </TableCell>
                            <TableCell data-testid={`text-student-class-${student.studentId}`}>
                              {student.class}
                            </TableCell>
                            <TableCell data-testid={`text-exam-count-${student.studentId}`}>
                              {hasResults ? `${studentResults.length} results` : "No results"}
                            </TableCell>
                            <TableCell data-testid={`text-performance-${student.studentId}`}>
                              <Badge variant={hasResults ? "default" : "secondary"}>
                                {overallStatus}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Button
                                variant="outline"
                                size="sm"
                                disabled={!hasResults}
                                onClick={() => handlePrintReport(student)}
                                data-testid={`button-print-report-card-${student.studentId}`}
                              >
                                <FileText className="h-4 w-4 mr-1" />
                                Print Report
                              </Button>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="fee-reports">
            <div className="space-y-6">
              {/* Fee Collection Summary */}
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>Fee Collection Report</CardTitle>
                    <div className="flex space-x-2">
                      <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                        <SelectTrigger className="w-48" data-testid="select-report-month">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Array.from({ length: 12 }, (_, i) => {
                            const date = new Date();
                            date.setMonth(date.getMonth() - i);
                            const value = date.toISOString().slice(0, 7);
                            const label = date.toLocaleDateString('en-US', { year: 'numeric', month: 'long' });
                            return (
                              <SelectItem key={value} value={value}>{label}</SelectItem>
                            );
                          })}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Class</TableHead>
                          <TableHead>Total Students</TableHead>
                          <TableHead>Amount Collected</TableHead>
                          <TableHead>Pending Count</TableHead>
                          <TableHead>Collection Rate</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {classWiseStats.map((stat) => (
                          <TableRow key={stat.class} data-testid={`row-class-fee-${stat.class.toLowerCase().replace(/\s+/g, '-')}`}>
                            <TableCell className="font-medium">{stat.class}</TableCell>
                            <TableCell data-testid={`text-total-students-${stat.class.toLowerCase().replace(/\s+/g, '-')}`}>
                              {stat.totalStudents}
                            </TableCell>
                            <TableCell className="text-green-600 font-medium" data-testid={`text-collected-${stat.class.toLowerCase().replace(/\s+/g, '-')}`}>
                              {formatCurrency(stat.collected)}
                            </TableCell>
                            <TableCell className="text-red-600" data-testid={`text-pending-count-${stat.class.toLowerCase().replace(/\s+/g, '-')}`}>
                              {stat.pendingCount}
                            </TableCell>
                            <TableCell data-testid={`text-collection-rate-${stat.class.toLowerCase().replace(/\s+/g, '-')}`}>
                              <Badge variant={stat.collectionRate >= 80 ? "default" : "destructive"}>
                                {stat.collectionRate.toFixed(1)}%
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              {/* Recent Payments */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Payment Receipts</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Receipt No.</TableHead>
                          <TableHead>Student</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {monthlyPayments.slice(0, 10).map((payment) => {
                          const student = students.find(s => s.studentId === payment.studentId);
                          return (
                            <TableRow key={payment.id} data-testid={`row-payment-receipt-${payment.receiptNumber}`}>
                              <TableCell className="font-medium">{payment.receiptNumber}</TableCell>
                              <TableCell>{student?.name || "Unknown Student"}</TableCell>
                              <TableCell className="text-green-600 font-medium">
                                {formatCurrency(payment.amount)}
                              </TableCell>
                              <TableCell>{new Date(payment.paymentDate).toLocaleDateString()}</TableCell>
                              <TableCell>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handlePrintReceipt(payment)}
                                  data-testid={`button-print-receipt-${payment.receiptNumber}`}
                                >
                                  <Printer className="h-4 w-4 mr-1" />
                                  Print
                                </Button>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="exam-reports">
            <Card>
              <CardHeader>
                <CardTitle>Exam Performance Report</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Exam Name</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Class</TableHead>
                        <TableHead>Students Appeared</TableHead>
                        <TableHead>Students Passed</TableHead>
                        <TableHead>Pass Rate</TableHead>
                        <TableHead>Performance</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {examPerformanceStats.map(({ exam, totalStudents, passedStudents, passRate }) => (
                        <TableRow key={exam.id} data-testid={`row-exam-performance-${exam.id}`}>
                          <TableCell className="font-medium" data-testid={`text-exam-name-${exam.id}`}>
                            {exam.name}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{exam.type.toUpperCase()}</Badge>
                          </TableCell>
                          <TableCell data-testid={`text-exam-class-${exam.id}`}>{exam.class}</TableCell>
                          <TableCell data-testid={`text-total-appeared-${exam.id}`}>{totalStudents}</TableCell>
                          <TableCell className="text-green-600" data-testid={`text-total-passed-${exam.id}`}>
                            {passedStudents}
                          </TableCell>
                          <TableCell data-testid={`text-pass-rate-${exam.id}`}>
                            <Badge variant={passRate >= 75 ? "default" : passRate >= 50 ? "secondary" : "destructive"}>
                              {passRate.toFixed(1)}%
                            </Badge>
                          </TableCell>
                          <TableCell data-testid={`text-performance-rating-${exam.id}`}>
                            {passRate >= 75 ? "Excellent" : passRate >= 50 ? "Good" : "Needs Improvement"}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="summary">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Total Students</p>
                      <p className="text-2xl font-bold text-foreground" data-testid="summary-total-students">
                        {students.length}
                      </p>
                    </div>
                    <Users className="h-8 w-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Monthly Collection</p>
                      <p className="text-2xl font-bold text-green-600" data-testid="summary-monthly-collection">
                        {formatCurrency(monthlyPayments.reduce((sum, p) => sum + parseFloat(p.amount), 0))}
                      </p>
                    </div>
                    <DollarSign className="h-8 w-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Pending Fees</p>
                      <p className="text-2xl font-bold text-orange-600" data-testid="summary-pending-students">
                        {pendingFeeStudents.length}
                      </p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-orange-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Active Exams</p>
                      <p className="text-2xl font-bold text-purple-600" data-testid="summary-active-exams">
                        {exams.length}
                      </p>
                    </div>
                    <BarChart3 className="h-8 w-8 text-purple-600" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Print Templates */}
      {selectedStudent && reportType === "report-card" && (
        <div className="hidden print:block">
          <ReportCardTemplate student={selectedStudent} />
        </div>
      )}

      {selectedPayment && reportType === "receipt" && (
        <div className="hidden print:block">
          <ReceiptTemplate payment={selectedPayment} />
        </div>
      )}
    </div>
  );
}
