import { User } from "lucide-react";

interface HeaderProps {
  title: string;
  description: string;
  children?: React.ReactNode;
}

export default function Header({ title, description, children }: HeaderProps) {
  const currentDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <header className="bg-card border-b border-border px-6 py-4 no-print">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-semibold text-foreground" data-testid="page-title">{title}</h2>
          <p className="text-muted-foreground" data-testid="page-description">{description}</p>
        </div>
        <div className="flex items-center space-x-4">
          {children}
          <span className="text-sm text-muted-foreground" data-testid="current-date">{currentDate}</span>
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
            <User className="text-primary-foreground text-sm" />
          </div>
        </div>
      </div>
    </header>
  );
}
