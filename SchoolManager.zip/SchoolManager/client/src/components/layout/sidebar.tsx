import { Link, useLocation } from "wouter";
import { GraduationCap, Users, Presentation, ClipboardList, DollarSign, BarChart3, Settings, LogOut, Gauge } from "lucide-react";
import { cn } from "@/lib/utils";

const navigation = [
  { name: "Dashboard", href: "/", icon: Gauge },
  { name: "Students", href: "/students", icon: Users },
  { name: "Classes & Subjects", href: "/classes", icon: Presentation },
  { name: "Exams & Results", href: "/exams", icon: ClipboardList },
  { name: "Fee Management", href: "/fees", icon: DollarSign },
  { name: "Reports", href: "/reports", icon: BarChart3 },
];

const secondaryNavigation = [
  { name: "Settings", href: "/settings", icon: Settings },
  { name: "Logout", href: "/logout", icon: LogOut },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-64 bg-card border-r border-border flex-shrink-0 no-print">
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <GraduationCap className="text-primary-foreground text-lg" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-foreground">Universal Model School</h1>
            <p className="text-sm text-muted-foreground">Management System</p>
          </div>
        </div>
      </div>
      
      <nav className="p-4 space-y-2">
        {navigation.map((item) => {
          const isActive = location === item.href;
          return (
            <Link 
              key={item.name}
              href={item.href} 
              className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-md transition-colors",
                "hover:bg-accent hover:text-accent-foreground",
                isActive ? "sidebar-active" : ""
              )}
              data-testid={`nav-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.name}</span>
            </Link>
          );
        })}
        
        <div className="pt-4 border-t border-border">
          {secondaryNavigation.map((item) => (
            <Link 
              key={item.name}
              href={item.href} 
              className="flex items-center space-x-3 px-3 py-2 rounded-md hover:bg-accent hover:text-accent-foreground transition-colors"
              data-testid={`nav-${item.name.toLowerCase()}`}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.name}</span>
            </Link>
          ))}
        </div>
      </nav>
    </aside>
  );
}
