import { FeePayment, Student } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { formatCurrency, convertNumberToWords } from "@/lib/calculations";

interface ReceiptTemplateProps {
  payment: FeePayment;
}

export default function ReceiptTemplate({ payment }: ReceiptTemplateProps) {
  const { data: students = [] } = useQuery<Student[]>({
    queryKey: ['/api/students'],
  });

  const student = students.find(s => s.studentId === payment.studentId);

  if (!student) return null;

  return (
    <div className="print-only p-8 bg-white max-w-4xl mx-auto">
      <div className="text-center border-b-2 border-gray-800 pb-4 mb-6">
        <h1 className="text-2xl font-bold">Universal Model School</h1>
        <p className="text-gray-600">123 Education Street, School City - 123456</p>
        <p className="text-gray-600">Phone: +91 98765 43210 | Email: info@universalmodelschool.edu</p>
      </div>
      
      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-4">Fee Receipt</h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p><strong>Receipt No:</strong> {payment.receiptNumber}</p>
            <p><strong>Student ID:</strong> {student.studentId}</p>
            <p><strong>Student Name:</strong> {student.name}</p>
            <p><strong>Class:</strong> {student.class}</p>
          </div>
          <div>
            <p><strong>Date:</strong> {new Date(payment.paymentDate).toLocaleDateString()}</p>
            <p><strong>Payment Mode:</strong> {payment.paymentMode}</p>
            <p><strong>Father's Name:</strong> {student.fatherName}</p>
            <p><strong>Phone:</strong> {student.phone}</p>
          </div>
        </div>
      </div>

      <table className="w-full border border-gray-800 mb-6">
        <thead>
          <tr className="bg-gray-100">
            <th className="border border-gray-800 px-4 py-2 text-left">Particulars</th>
            <th className="border border-gray-800 px-4 py-2 text-right">Amount (₹)</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="border border-gray-800 px-4 py-2">
              {payment.feeType}
              {payment.month && ` - ${new Date(payment.month + '-01').toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}`}
            </td>
            <td className="border border-gray-800 px-4 py-2 text-right">
              {parseFloat(payment.amount).toFixed(2)}
            </td>
          </tr>
          <tr className="bg-gray-50 font-semibold">
            <td className="border border-gray-800 px-4 py-2">Total Amount</td>
            <td className="border border-gray-800 px-4 py-2 text-right">
              ₹{parseFloat(payment.amount).toFixed(2)}
            </td>
          </tr>
        </tbody>
      </table>

      <div className="mb-6">
        <p><strong>Amount in Words:</strong> {convertNumberToWords(parseFloat(payment.amount))}</p>
        {payment.remarks && (
          <p className="mt-2"><strong>Remarks:</strong> {payment.remarks}</p>
        )}
      </div>

      <div className="flex justify-between items-end">
        <div>
          <p className="text-sm text-gray-600">This is a computer generated receipt.</p>
          <p className="text-sm text-gray-600">Receipt generated on: {new Date().toLocaleDateString()}</p>
        </div>
        <div className="text-center">
          <div className="border-t border-gray-800 pt-2 mt-12 w-48">
            <p>Authorized Signature</p>
          </div>
        </div>
      </div>
    </div>
  );
}
