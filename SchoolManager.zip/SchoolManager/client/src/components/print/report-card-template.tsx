import { useQuery } from "@tanstack/react-query";
import { Student, ExamResult, Exam } from "@shared/schema";
import { calculateTotalMarks, getOverallGrade, calculateGrade } from "@/lib/calculations";

interface ReportCardTemplateProps {
  student: Student;
}

export default function ReportCardTemplate({ student }: ReportCardTemplateProps) {
  const { data: examResults = [] } = useQuery<ExamResult[]>({
    queryKey: ['/api/exam-results/student', student.studentId],
  });

  const { data: exams = [] } = useQuery<Exam[]>({
    queryKey: ['/api/exams'],
  });

  // Group results by exam
  const resultsByExam = examResults.reduce((acc, result) => {
    if (!acc[result.examId]) {
      acc[result.examId] = [];
    }
    acc[result.examId].push(result);
    return acc;
  }, {} as Record<string, ExamResult[]>);

  const getExamName = (examId: string): string => {
    const exam = exams.find(e => e.id === examId);
    return exam?.name || "Unknown Exam";
  };

  const getExamType = (examId: string): string => {
    const exam = exams.find(e => e.id === examId);
    return exam?.type || "unknown";
  };

  return (
    <div className="print-only p-8 bg-white max-w-4xl mx-auto">
      {/* Header */}
      <div className="text-center border-b-2 border-gray-800 pb-4 mb-6">
        <h1 className="text-3xl font-bold">Universal Model School</h1>
        <p className="text-gray-600">123 Education Street, School City - 123456</p>
        <p className="text-gray-600">Phone: +91 98765 43210 | Email: info@universalmodelschool.edu</p>
        <h2 className="text-xl font-semibold mt-4">STUDENT REPORT CARD</h2>
      </div>

      {/* Student Information */}
      <div className="grid grid-cols-2 gap-8 mb-6">
        <div>
          <h3 className="text-lg font-semibold mb-3 border-b border-gray-400">Student Information</h3>
          <div className="space-y-2">
            <p><strong>Name:</strong> {student.name}</p>
            <p><strong>Student ID:</strong> {student.studentId}</p>
            <p><strong>Class:</strong> {student.class}</p>
            <p><strong>Roll Number:</strong> {student.rollNumber}</p>
            <p><strong>Father's Name:</strong> {student.fatherName}</p>
          </div>
        </div>
        <div>
          <h3 className="text-lg font-semibold mb-3 border-b border-gray-400">Session Information</h3>
          <div className="space-y-2">
            <p><strong>Academic Year:</strong> {new Date().getFullYear()}</p>
            <p><strong>Date of Birth:</strong> {new Date(student.dateOfBirth).toLocaleDateString()}</p>
            <p><strong>Admission Date:</strong> {new Date(student.admissionDate).toLocaleDateString()}</p>
          </div>
        </div>
      </div>

      {/* Exam Results */}
      {Object.entries(resultsByExam).map(([examId, results]) => {
        const examName = getExamName(examId);
        const examType = getExamType(examId);
        const { obtained, total, percentage } = calculateTotalMarks(results);
        const overallGrade = getOverallGrade(percentage);
        const failedSubjects = results.filter(r => r.marks < 40);
        const isPassed = failedSubjects.length < 3;

        return (
          <div key={examId} className="mb-8">
            <h3 className="text-lg font-semibold mb-3 bg-gray-100 p-2">
              {examName} ({examType.toUpperCase()})
            </h3>
            
            <table className="w-full border border-gray-800 mb-4">
              <thead>
                <tr className="bg-gray-200">
                  <th className="border border-gray-800 px-4 py-2 text-left">Subject</th>
                  <th className="border border-gray-800 px-4 py-2 text-center">Marks Obtained</th>
                  <th className="border border-gray-800 px-4 py-2 text-center">Total Marks</th>
                  <th className="border border-gray-800 px-4 py-2 text-center">Percentage</th>
                  <th className="border border-gray-800 px-4 py-2 text-center">Grade</th>
                  <th className="border border-gray-800 px-4 py-2 text-center">Result</th>
                </tr>
              </thead>
              <tbody>
                {results.map((result) => (
                  <tr key={result.id}>
                    <td className="border border-gray-800 px-4 py-2">{result.subject}</td>
                    <td className="border border-gray-800 px-4 py-2 text-center">{result.marks}</td>
                    <td className="border border-gray-800 px-4 py-2 text-center">{result.totalMarks}</td>
                    <td className="border border-gray-800 px-4 py-2 text-center">
                      {Math.round((result.marks / result.totalMarks) * 100)}%
                    </td>
                    <td className="border border-gray-800 px-4 py-2 text-center font-semibold">
                      {calculateGrade(result.marks, result.totalMarks)}
                    </td>
                    <td className="border border-gray-800 px-4 py-2 text-center">
                      <span className={result.marks >= 40 ? "text-green-600 font-semibold" : "text-red-600 font-semibold"}>
                        {result.marks >= 40 ? "PASS" : "FAIL"}
                      </span>
                    </td>
                  </tr>
                ))}
                <tr className="bg-gray-100 font-semibold">
                  <td className="border border-gray-800 px-4 py-2">TOTAL</td>
                  <td className="border border-gray-800 px-4 py-2 text-center">{obtained}</td>
                  <td className="border border-gray-800 px-4 py-2 text-center">{total}</td>
                  <td className="border border-gray-800 px-4 py-2 text-center">{percentage}%</td>
                  <td className="border border-gray-800 px-4 py-2 text-center">{overallGrade}</td>
                  <td className="border border-gray-800 px-4 py-2 text-center">
                    <span className={isPassed ? "text-green-600 font-bold" : "text-red-600 font-bold"}>
                      {isPassed ? "PASS" : "FAIL"}
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>

            {/* Performance Summary */}
            <div className="grid grid-cols-3 gap-4 mb-4 text-sm">
              <div className="bg-blue-50 p-3 rounded">
                <strong>Subjects Attempted:</strong> {results.length}
              </div>
              <div className="bg-green-50 p-3 rounded">
                <strong>Subjects Passed:</strong> {results.filter(r => r.marks >= 40).length}
              </div>
              <div className="bg-red-50 p-3 rounded">
                <strong>Subjects Failed:</strong> {failedSubjects.length}
              </div>
            </div>

            {!isPassed && (
              <div className="bg-red-100 border border-red-400 p-3 rounded mb-4">
                <strong className="text-red-800">Note:</strong> 
                <span className="text-red-700 ml-1">
                  Student has failed in {failedSubjects.length} subjects. 
                  Failing in 3 or more subjects results in overall failure.
                </span>
              </div>
            )}
          </div>
        );
      })}

      {/* Grading Scale */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-3 border-b border-gray-400">Grading Scale</h3>
        <div className="grid grid-cols-7 gap-2 text-center text-sm">
          <div className="bg-green-100 p-2 rounded">
            <div className="font-semibold">A+</div>
            <div>90-100</div>
          </div>
          <div className="bg-green-100 p-2 rounded">
            <div className="font-semibold">A</div>
            <div>80-89</div>
          </div>
          <div className="bg-blue-100 p-2 rounded">
            <div className="font-semibold">B+</div>
            <div>70-79</div>
          </div>
          <div className="bg-blue-100 p-2 rounded">
            <div className="font-semibold">B</div>
            <div>60-69</div>
          </div>
          <div className="bg-yellow-100 p-2 rounded">
            <div className="font-semibold">C+</div>
            <div>50-59</div>
          </div>
          <div className="bg-yellow-100 p-2 rounded">
            <div className="font-semibold">C</div>
            <div>40-49</div>
          </div>
          <div className="bg-red-100 p-2 rounded">
            <div className="font-semibold">F</div>
            <div>Below 40</div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="grid grid-cols-3 gap-8 pt-8 border-t border-gray-400">
        <div className="text-center">
          <div className="border-t border-gray-800 pt-2 mt-16">
            <p className="font-semibold">Class Teacher</p>
          </div>
        </div>
        <div className="text-center">
          <div className="border-t border-gray-800 pt-2 mt-16">
            <p className="font-semibold">Principal</p>
          </div>
        </div>
        <div className="text-center">
          <div className="border-t border-gray-800 pt-2 mt-16">
            <p className="font-semibold">Parent/Guardian Signature</p>
          </div>
        </div>
      </div>

      <div className="text-center mt-6 text-sm text-gray-600">
        <p>This is a computer generated report card.</p>
        <p>Report generated on: {new Date().toLocaleDateString()}</p>
      </div>
    </div>
  );
}
