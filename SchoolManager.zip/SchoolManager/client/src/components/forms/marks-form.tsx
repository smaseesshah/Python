import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Exam, Student, Class, ExamResult } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { calculateGrade, calculatePercentage } from "@/lib/calculations";

interface MarksFormProps {
  exam: Exam;
  onSuccess?: () => void;
}

interface StudentMarks {
  studentId: string;
  marks: { [subject: string]: number };
}

export default function MarksForm({ exam, onSuccess }: MarksFormProps) {
  const [studentMarks, setStudentMarks] = useState<StudentMarks[]>([]);
  const { toast } = useToast();

  const { data: students = [] } = useQuery<Student[]>({
    queryKey: ['/api/students/class', exam.class],
  });

  const { data: classes = [] } = useQuery<Class[]>({
    queryKey: ['/api/classes'],
  });

  const { data: existingResults = [] } = useQuery<ExamResult[]>({
    queryKey: ['/api/exam-results/exam', exam.id],
  });

  const saveMarksMutation = useMutation({
    mutationFn: async (marks: { studentId: string; subject: string; marks: number; totalMarks: number }[]) => {
      const promises = marks.map(mark => 
        apiRequest('POST', '/api/exam-results', {
          examId: exam.id,
          ...mark
        })
      );
      return Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/exam-results'] });
      toast({
        title: "Success",
        description: "Marks saved successfully",
      });
      onSuccess?.();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save marks",
        variant: "destructive",
      });
    }
  });

  const examClass = classes.find(c => c.name === exam.class);
  const subjects = examClass?.subjects || [];

  const handleMarksChange = (studentId: string, subject: string, marks: string) => {
    const numMarks = parseInt(marks) || 0;
    
    setStudentMarks(prev => {
      const existingIndex = prev.findIndex(sm => sm.studentId === studentId);
      
      if (existingIndex >= 0) {
        const updated = [...prev];
        updated[existingIndex] = {
          ...updated[existingIndex],
          marks: { ...updated[existingIndex].marks, [subject]: numMarks }
        };
        return updated;
      } else {
        return [...prev, { studentId, marks: { [subject]: numMarks } }];
      }
    });
  };

  const getStudentMarks = (studentId: string, subject: string): number => {
    const student = studentMarks.find(sm => sm.studentId === studentId);
    return student?.marks[subject] || 0;
  };

  const getExistingMarks = (studentId: string, subject: string): number => {
    const result = existingResults.find(r => r.studentId === studentId && r.subject === subject);
    return result?.marks || 0;
  };

  const handleSaveMarks = () => {
    const allMarks: { studentId: string; subject: string; marks: number; totalMarks: number }[] = [];
    
    studentMarks.forEach(student => {
      subjects.forEach(subject => {
        if (student.marks[subject] !== undefined) {
          allMarks.push({
            studentId: student.studentId,
            subject,
            marks: student.marks[subject],
            totalMarks: 100
          });
        }
      });
    });

    if (allMarks.length === 0) {
      toast({
        title: "Error",
        description: "Please enter at least one mark",
        variant: "destructive",
      });
      return;
    }

    saveMarksMutation.mutate(allMarks);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Exam Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div><strong>Exam:</strong> {exam.name}</div>
            <div><strong>Class:</strong> {exam.class}</div>
            <div><strong>Type:</strong> {exam.type}</div>
            <div><strong>Year:</strong> {exam.year}</div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Enter Marks</CardTitle>
          <p className="text-sm text-muted-foreground">
            Enter marks out of 100. Marks below 40 are considered as fail.
          </p>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-48">Student</TableHead>
                  {subjects.map(subject => (
                    <TableHead key={subject} className="text-center min-w-24">
                      {subject}
                    </TableHead>
                  ))}
                  <TableHead className="text-center">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {students.map((student) => (
                  <TableRow key={student.id} data-testid={`row-marks-${student.studentId}`}>
                    <TableCell>
                      <div>
                        <div className="font-medium" data-testid={`text-marks-student-name-${student.studentId}`}>
                          {student.name}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {student.studentId}
                        </div>
                      </div>
                    </TableCell>
                    {subjects.map(subject => {
                      const currentMarks = getStudentMarks(student.studentId, subject);
                      const existingMarks = getExistingMarks(student.studentId, subject);
                      const displayMarks = currentMarks || existingMarks;
                      
                      return (
                        <TableCell key={subject} className="text-center">
                          <div className="space-y-1">
                            <Input
                              type="number"
                              min="0"
                              max="100"
                              className="w-20 mx-auto text-center"
                              value={currentMarks || ""}
                              onChange={(e) => handleMarksChange(student.studentId, subject, e.target.value)}
                              placeholder={existingMarks ? existingMarks.toString() : ""}
                              data-testid={`input-marks-${student.studentId}-${subject.toLowerCase().replace(/\s+/g, '-')}`}
                            />
                            {displayMarks > 0 && (
                              <div className="text-xs">
                                <Badge variant={displayMarks >= 40 ? "default" : "destructive"}>
                                  {calculateGrade(displayMarks)}
                                </Badge>
                              </div>
                            )}
                          </div>
                        </TableCell>
                      );
                    })}
                    <TableCell className="text-center">
                      <div className="text-xs text-muted-foreground">
                        {existingResults.filter(r => r.studentId === student.studentId).length > 0 
                          ? "Has results" 
                          : "No results"}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end space-x-2">
        <Button
          variant="outline"
          onClick={() => onSuccess?.()}
          data-testid="button-cancel-marks"
        >
          Cancel
        </Button>
        <Button 
          onClick={handleSaveMarks}
          disabled={saveMarksMutation.isPending}
          data-testid="button-save-marks"
        >
          {saveMarksMutation.isPending ? "Saving..." : "Save Marks"}
        </Button>
      </div>
    </div>
  );
}
